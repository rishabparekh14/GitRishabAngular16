import { Option } from './TestOptions';
import { Component, OnInit } from '@angular/core';
import { QuestionOptionService } from './TestQuestionAnswer-service';
import { Test } from './Test';

@Component({
    selector: 'question-answer-list',
    templateUrl: './Test-form.component.html'
})

export class QuestionAnswerComponent {
   
   test:Test[];
     domain:string
    stage:number;
    option:Option[];
// test1:Test=new Test();
// test2:Test=new Test();
// o1:Option=new Option();
// o2:Option=new Option();
    constructor(public qs: QuestionOptionService) {
       this.domain="Java"
       this.stage=3
    }

   // ngOnInit() {
         display(){
    
        // this.test1.question="hello";
        // this.o1.optionId=1;
        // this.o2.optionId=2;
        // this.o1.option="djkhjdjd";
        // this.o2.option="dfjkhdjkf";
        // this.test1.options=[this.o1,this.o2];

        // this.test2.question="hello";
        // this.test=[this.test1,this.test2];


        let url="http://localhost:9024/getQuestions/"+this.domain+"/"+this.stage
        this.qs.getQuestionsFromServer(url)
        .subscribe(data=>{
            this.test= data;
            console.log(JSON.stringify(this.test));

           // console.log(this.test.question);

        });
           
    }
   

}
