import { Component } from '@angular/core'
import {  Option } from './TestOptions';
export class Test {

    // constructor(
    //     public question: string,
    //     public domain: string,
    //     public stage: number,
    //     public options: TestOptions[]) {
    //     options: TestOptions;
    // }

     constructor(
        public question?: string,
        public domain?: string,
        public stage?: number,
        public questionId?: number,
        public options?: Option[]) {
    }

}