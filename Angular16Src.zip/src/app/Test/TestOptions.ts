export class Option{
    constructor( 
        public optionId?: number,
        public option?:string){
        
    }
}