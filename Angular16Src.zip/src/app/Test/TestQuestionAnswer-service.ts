import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Test } from './Test';
import { Option } from './TestOptions';


@Injectable()
export class QuestionOptionService {



    constructor(private http: HttpClient) {

    }
    getQuestionsFromServer(url:string): Observable<Test[]> {

       
           return this.http.get<Test[]>(url);
        

    }

}