import { LoginStudent } from './LoginStudent';
import { Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {providerDef} from '@angular/core/src/view';
import { Observable } from 'rxjs';

@Injectable()                               //DI
export class DatabaseEmailAndPasswordVerification{
    //injecting Angular's HttpClient API
    loginStudent : LoginStudent[];
    constructor(private http:HttpClient)
    {
            
    }

    sentToServerForVerification(loginStudent : LoginStudent) : Observable<object> {
        //our code to communicate with server will be here 
        let url="http://localhost:9024/verify";
        return this.http.post(url,loginStudent);
        
      

    }
  //  retrieveFromServer(url :string) : Observable<RegisterStudent[]>{
        //our code to communicate to the server call

       // let url = 'http://localhost:8081/pagination_jquery_ajax_webapp/ProductControllerServlet'
     //   return this.http.get<RegisterStudent[]>(url);
        

    //}
    
}
