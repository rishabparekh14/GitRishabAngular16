import {Component} from '@angular/core'


export class RegisterStudent{

    constructor(
        public fullName?:string,
        public emailAddress?:string,
        public mobileNumber?:number,
        public dateOfBirth?:number,
        public city?:string,
        public state?:string,
        public qualification?:string,
        public year?:number){

}
}