import { Component } from '@angular/core';

import {RegisterStudent} from './RegisterStudent';
import {RegisterServiceAddInDatabaseService} from './RegisterStudent-service'
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component ({
    selector:'register-data-in-database',
    templateUrl:'RegisterStudent-form.component.html'
})
export class RegisterFormComponent{

    registerStudent : RegisterStudent = new RegisterStudent();
    response : string

    keyPress(event: any) {
        const pattern = /[0-9\+\-\ ]/;
        let inputChar = String.fromCharCode(event.charCode);
        if (event.keyCode != 8 && !pattern.test(inputChar)) {
            event.preventDefault();
        }
    }


    constructor(public registerInDatabase : RegisterServiceAddInDatabaseService,private router :Router )
    {

    }
    regForm = new FormGroup({
        Name: new FormControl('', Validators.required),
        State: new FormControl('', Validators.required),
        City: new FormControl('', Validators.required),
        Email: new FormControl('', [Validators.required, Validators.email]),
        Password: new FormControl('', [Validators.required, Validators.minLength(8)]),
        ConfirmPassword: new FormControl('', [Validators.required, Validators.minLength(8)]),
        MobileNumber: new FormControl('', Validators.required)

    })


    add(mform)
    {
        this.registerInDatabase.sentToServer(this.registerStudent)
            .subscribe(data => { 
                console.log("====" + data);
                this.response=data.toString();

                var check=this.response;

                if(check == "true"){
                    console.log("inside if");
                    this.router.navigate(['./login']);
                }
                else{
                    console.log("inside else");
                    this.router.navigate(['./register']);
                }
            
            })
    }
}