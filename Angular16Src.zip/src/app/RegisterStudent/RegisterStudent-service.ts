import { RegisterStudent } from './RegisterStudent';
import { Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {providerDef} from '@angular/core/src/view';
import { Observable } from 'rxjs';

@Injectable()                               //DI
export class RegisterServiceAddInDatabaseService{
    //injecting Angular's HttpClient API
    registerStudent : RegisterStudent[];
    constructor(private http:HttpClient)
    {
            
    }

    sentToServer(registerStudent : RegisterStudent) : Observable<object> {
        //our code to communicate with server will be here 
        let url="http://localhost:9024/registerStudent/addInDatabase";
        return this.http.post(url,registerStudent);
        
      

    }
  //  retrieveFromServer(url :string) : Observable<RegisterStudent[]>{
        //our code to communicate to the server call

       // let url = 'http://localhost:8081/pagination_jquery_ajax_webapp/ProductControllerServlet'
     //   return this.http.get<RegisterStudent[]>(url);
        

    //}
    
}
