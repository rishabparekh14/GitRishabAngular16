import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { RouterModule }   from '@angular/router';
import { AppComponent } from './app.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RegisterFormComponent } from './RegisterStudent/RegisterStudent-form.component';
import { LoginFormComponent } from './LoginStudent/LoginStudent-form.component';
import { HomePageComponent } from './HomePage/HomePage.component';
import { RegisterServiceAddInDatabaseService } from './RegisterStudent/RegisterStudent-service';
import { DatabaseEmailAndPasswordVerification } from './LoginStudent/LoginStudent-service';
import { QuestionAnswerComponent } from './Test/Test-form.component';
import { QuestionOptionService } from './Test/TestQuestionAnswer-service';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
  //  LoginFormComponent,
    RegisterFormComponent,
    LoginFormComponent,
    QuestionAnswerComponent
   
  ],
  imports: [
    
    BrowserModule,
    HttpClientModule,
    FormsModule,    
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    RouterModule.forRoot([
      {path: 'home',component:HomePageComponent },
      {path: 'login',component:LoginFormComponent },
      {path: 'register',component:RegisterFormComponent },
      {path: 'test',component:QuestionAnswerComponent }
     
  ])
  ],
  providers: [HttpClient, RegisterServiceAddInDatabaseService,DatabaseEmailAndPasswordVerification,QuestionOptionService],
  bootstrap: [AppComponent]
})
export class AppModule { }
