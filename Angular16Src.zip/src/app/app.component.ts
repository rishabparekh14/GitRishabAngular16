import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  template: `
            <home-page></home-page>
            <div> 
              <router-outlet>
              </router-outlet>
            </div>
   
     
   <!--<div style="text-align:left">
   <ul class="navbar-nav">
    <li><a [routerLink]="['/login-verification-page']">Login</a></li>
    <li><a [routerLink]="['/register-data-in-database']">Register</a></li>
</ul>
    <div class='container'>
    
    </div>-->
  
 ` ,
  styles: []
 
})
export class AppComponent {
  title = 'LTIExamPortalApp';
}
