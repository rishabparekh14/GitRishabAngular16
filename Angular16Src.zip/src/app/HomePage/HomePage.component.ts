import { Component } from '@angular/core';

import { Router } from '@angular/router';
//import { DatabaseEmailAndPasswordVerification } from '../LoginStudent/LoginStudent-service';


@Component({
  selector: 'home-page',
  templateUrl: './HomePage.component.html'
 
})
export class HomePageComponent {


}